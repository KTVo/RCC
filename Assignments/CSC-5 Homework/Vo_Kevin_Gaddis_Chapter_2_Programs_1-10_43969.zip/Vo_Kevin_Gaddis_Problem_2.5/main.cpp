/* 
 * name:  Kevin Vo
 * date:  Feb. 25th, 2012
 * Problem:  Gaddis Ch.2 Problem: 5
 * Description:  Averaging series values
 * preferences in Average of Values
 * 
 */
#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv) {
    
    double sum, avg;
    
    sum = 28+32+37+24+33;
    avg = sum / 5;
    
    cout<<"Gaddis Problem 2.5 Answer:\n";
    cout<<""<<endl;
    cout<<"Average = "<<avg<<endl;

            
    return 0;
}

