/* 
 * name:  Kevin Vo
 * date:  Feb. 26th, 2012
 * Problem:  Hello World
 * Description:  Creating a Hello World Program
 * preferences in saying hi to the world!
 * 
 */
#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char** argv) {
    
//Outputted section of the program
    cout<<"Hello World\n"<<endl;//This is the string that will be be displaying
    return 0;
}

